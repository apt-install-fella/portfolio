// ⚠️ Remplace ce contenu par tes vraies infos avant de déployer.
export const projects = [
  {
    emoji: "🎮",
    tag: "T3-T4 · jeu sérieux",
    title: "Développement d'un jeu sérieux",
    description:
      "En équipe de quatre, développement d'un jeu à but pédagogique à partir d'un cahier des charges, sans expérience préalable du moteur utilisé par l'équipe.",
    stack: ["Godot", "GDScript", "Travail d'équipe"],
    repoUrl: "#",
    demoUrl: "",
  },
  {
    emoji: "🐉",
    tag: "projet IUT · Níðhöggr",
    title: "Níðhöggr",
    description:
      "À compléter : décris l'objectif du projet, ton rôle, et une compétence clé mise en avant.",
    stack: ["À définir", "À définir"],
    repoUrl: "#",
    demoUrl: "",
  },
  {
    emoji: "📊",
    tag: "projet personnel · data",
    title: "Analyse de données — à définir",
    description:
      "3ᵉ projet à choisir, idéalement cohérent avec ton intérêt pour la data (dashboard, analyse exploratoire, etc.).",
    stack: ["Python", "Pandas", "Power BI"],
    repoUrl: "#",
    demoUrl: "",
  },
];
